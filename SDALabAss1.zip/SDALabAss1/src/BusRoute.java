import java.util.Date;

public class BusRoute {
    private int routeId;
    private String routeName;
    private Date departureTime;
    private Date arrivalTime;
    private BusDriver busDriver;

    public BusRoute(int routeId, String routeName, Date departureTime, Date arrivalTime) {
        this.routeId = routeId;
        this.routeName = routeName;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
    }

    public void setBusDriver(BusDriver busDriver) {
        this.busDriver = busDriver;
    }

    public BusDriver getBusDriver() {
        return busDriver;
    }

    // Other getters
    public int getRouteId() {
        return routeId;
    }

    public String getRouteName() {
        return routeName;
    }

    public Date getDepartureTime() {
        return departureTime;
    }

    public Date getArrivalTime() {
        return arrivalTime;
    }
}
