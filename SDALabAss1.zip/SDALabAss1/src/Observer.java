public interface Observer {
    void update(String message);  // Method to receive notifications from the Subject
}
