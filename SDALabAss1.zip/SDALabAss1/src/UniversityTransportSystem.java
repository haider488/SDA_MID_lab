import java.util.Date;

public class UniversityTransportSystem {

    public static void main(String[] args) {
        TransportManagementSystem transportSystem = new TransportManagementSystem();

        // Create Students
        Student student1 = new Student(1, "Alice");
        Student student2 = new Student(2, "Bob");

        // Create BusRoute and BusDriver
        BusRoute busRoute = new BusRoute(1, "Route A", new Date(System.currentTimeMillis() + 3600 * 1000), new Date(System.currentTimeMillis() + 7200 * 1000));
        BusDriver busDriver = new BusDriver(101, "John Doe", busRoute);
        busRoute.setBusDriver(busDriver); // Set bus driver to bus route

        // Register Payments for Students
        transportSystem.paymentSystem.recordPayment(student1);  // Alice has paid
        transportSystem.paymentSystem.recordPayment(student2);  // Bob has paid

        // Register Students for Notifications
        transportSystem.registerStudentForNotifications(student1);  // Alice is registered
        transportSystem.registerStudentForNotifications(student2);  // Bob is registered

        // Driver sends notification for arrival time
        busDriver.notifyArrivalTime(transportSystem.transportInCharge);  // Notify registered students
    }
}
