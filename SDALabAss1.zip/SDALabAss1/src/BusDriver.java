public class BusDriver {
    private int driverId;
    private String driverName;
    private BusRoute busRoute;

    public BusDriver(int driverId, String driverName, BusRoute busRoute) {
        this.driverId = driverId;
        this.driverName = driverName;
        this.busRoute = busRoute;
    }

    // Notify registered observers (students) about the bus arrival time
    public void notifyArrivalTime(TransportInCharge transportInCharge) {
        String message = "Bus " + busRoute.getRouteName() + " will arrive at " + busRoute.getArrivalTime();
        transportInCharge.notifyObservers(message);
    }

    // Getters and setters
    public int getDriverId() {
        return driverId;
    }

    public String getDriverName() {
        return driverName;
    }

    public BusRoute getBusRoute() {
        return busRoute;
    }
}
