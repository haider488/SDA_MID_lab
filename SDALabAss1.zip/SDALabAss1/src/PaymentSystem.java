import java.util.HashMap;
import java.util.Map;

public class PaymentSystem {
    private Map<Integer, Boolean> paymentDatabase;

    public PaymentSystem() {
        paymentDatabase = new HashMap<>();
    }

    public boolean checkPaymentStatus(Student student) {
        return paymentDatabase.getOrDefault(student.getStudentId(), false);
    }

    public void recordPayment(Student student) {
        paymentDatabase.put(student.getStudentId(), true);
        System.out.println(student.getName() + " has paid for transport.");
    }
}
