public class TransportManagementSystem {
    PaymentSystem paymentSystem;
    TransportInCharge transportInCharge;

    public TransportManagementSystem() {
        paymentSystem = new PaymentSystem();
        transportInCharge = new TransportInCharge();
    }

    public void registerStudentForNotifications(Student student) {
        if (paymentSystem.checkPaymentStatus(student)) {
            transportInCharge.registerObserver(student);
            System.out.println(student.getName() + " is now registered for notifications.");
        } else {
            System.out.println(student.getName() + " has not paid, cannot register for notifications.");
        }
    }
}
